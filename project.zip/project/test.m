clear
clc
M=10;
N=10;
Judge=ones(M,N);
for m=1:M
    for n=1:N
        beta=ones(m*n,1);
        A=coe_f2(m,n);
        Stair=gauss_f2(A,beta,m*n);
        sol=printsol(Stair,m*n+1);
        b=mod(A*sol',2)';
        if sum(b)~=m*n
            Judge(m,n)=0;
        end
    end
end
format compact
disp(Judge)
            
